package com.cg.emp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class PageServlet
 */
@WebServlet("/PageServlet")
public class PageServlet extends HttpServlet {
	static Map<String, Employee> map = new HashMap<>();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// request.getRequestDispatcher("Login.html").include(request,
		// response);
		boolean result = true;
		HttpSession session = request.getSession();

		try{
		String id = request.getParameter("id");
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String phone = request.getParameter("phone");
		Employee employee = new Employee();
		if (id.matches("[0-9]{1,3}")) {
			employee.setId(id);

		} else {
			result = false;
			//out.write("<h4>id should have minimum of 1 and maximum of 3 digits</h4>");
			request.setAttribute("error1", "Id should have minimum of 1 and maximum of 3 digits");
		}
		if (fname.matches("[A-Za-z]{3,20}")) {
			employee.setFname(fname);
		} else {
			result = false;
			//out.print("<h4>Enter valid fisrt name</h4>");
			request.setAttribute("error2", "Enter valid fisrt name");
		}
		if (lname.matches("[A-Za-z]{3,20}")) {
			employee.setLname(lname);
		} else {
			result = false;
			//out.print("<h4>Enter valid last name</h4>");
			request.setAttribute("error3", "Enter valid last name");
		}
		if (phone.matches("[6-9]{1}[0-9]{9}")) {
			employee.setPhone(phone);
		} else {
			result = false;
			//out.print("<h4>Enter valid phone number</h4>");
			request.setAttribute("error4", "Enter valid phone number");
		}
		map.put(employee.getId(), employee);
		

		if (result == true) {
		
			
			session.setAttribute("employee", map);

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("success.jsp");

			dispatcher.forward(request, response);
		} else {
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("Login.jsp");

			dispatcher.include(request, response);

		}
	}catch(Exception exception){
		System.err.println("<h4>Enter all fields</h4>");
	}
		
	}
		
	
}
