package com.cg.emp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class PageServlet2
 */
@WebServlet("/PageServlet2")
public class PageServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
      
        
          
        HttpSession session=request.getSession(); 
        PrintWriter out=response.getWriter();
             Map<String, Employee> employee =(Map<String, Employee>) session.getAttribute("employee");  
             for (Entry<String, Employee> entry : employee.entrySet()) {
            	
                 out.println("id: "+entry.getKey()+""+entry.getValue());
                 out.write("<br>");
				
			}
           
           
           
	}
	
	}


